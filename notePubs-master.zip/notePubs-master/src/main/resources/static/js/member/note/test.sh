newlec@NVME-PC MINGW64 /c/Work/STSWorkspace/Hello (dev)
$ git merge dev3 --no-ff
Merge made by the 'recursive' strategy.
 src/ExamConsole.java | 4 +++-
 1 file changed, 3 insertions(+), 1 deletion(-)