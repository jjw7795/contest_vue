package com.notepubs.web.dao;

import java.util.List;

import com.notepubs.web.entity.Category;

public interface CategoryDao {
	List<Category> getList();
}
