package com.notepubs.web.dao;

import java.util.List;
import com.notepubs.web.entity.MyCategory;


public interface MyCategoryDao {
	List<MyCategory> getList();

}
