package com.notepubs.web.dao;

import java.util.List;

import com.notepubs.web.entity.Comment;

public interface CommentDao {

	List<Comment> getList();
}
