package com.notepubs.web.dao;

import java.util.List;

import com.notepubs.web.entity.Printed;

public interface PrintedDao {

	List<Printed> getList();
	
}
