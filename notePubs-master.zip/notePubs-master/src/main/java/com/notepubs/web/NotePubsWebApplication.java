package com.notepubs.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NotePubsWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(NotePubsWebApplication.class, args);
	}

}
